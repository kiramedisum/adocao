<!-- ======= Call To Action Section ======= -->
<section id="call-to-action" class="call-to-action">
          <div class="container text-center" data-aos="zoom-out">
            <a href="https://www.youtube.com/watch?v=LXb3EKWsInQ" class="glightbox play-btn"></a>
            <h3>Call To Action</h3>
            <p> 
             Fornecemos informações valiosas sobre cuidados e treinamento, para garantir que você
              esteja preparado para a jornada de cuidar de um novo amigo de quatro patas. 
              Venha transforma as vida uma vida!
            </p>
            <a class="cta-btn" href="#">Call To Action</a>
          </div>
        </section><!-- End Call To Action Section --> 